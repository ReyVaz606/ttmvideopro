-- TTM Assistant bridge to DaVinci Resolve Studio (run with the fuscript that comes with DaVinci).
-- Usage: fuscript -l lua ResolveBridge.lua <command> [arguments…]
-- Prints one result line "TTM<TAB>ok|err|none<TAB>message" and, for lists, lines "TTMITEM<TAB>…".
-- "none" means the API could not do it.

local function out(status, message) print("TTM\t" .. status .. "\t" .. tostring(message or "")) end
local function item(...) print("TTMITEM\t" .. table.concat({...}, "\t")) end
local function list(t) local o = {} for _, v in pairs(t or {}) do if type(v) ~= "number" then o[#o + 1] = v end end return o end

local resolve = bmd.scriptapp("Resolve")
if not resolve then out("err", "noapi") return end
local command = arg[1] or "status"

if command == "status" then
  out("ok", (resolve:GetProductName() or "") .. "|" .. (resolve:GetVersionString() or "") .. "|" .. (resolve:GetCurrentPage() or ""))
  return
end
if command == "page" then
  if resolve:OpenPage(string.lower(arg[2] or "")) then out("ok", arg[2]) else out("none", "page") end
  return
end
if command == "effects" then
  local kind = (arg[2] == "audio") and "audio" or "video"
  for _, e in ipairs(list(resolve:GetEffectsList(kind))) do item(e.category or "", e.name or "", e.id or "") end
  out("ok", "")
  return
end

-- 0.9.11: every Fusion page tool DaVinci has (built-in tools, Fuses, plugins such as Krokodove, Resolve FX), from
-- Fusion's own registry, as rows "category, name, id, short id". Hidden ones (Group, Macro, PipeRouter…) are left out,
-- like Fusion's Select Tool window does. Read only: nothing is added or changed.
if command == "fusiontools" then
  local fu = resolve:Fusion()
  if not fu then out("none", "") return end
  for _, reg in pairs(fu:GetRegList(fu.CT_Tool) or {}) do
    local a = reg:GetAttrs() or {}
    if not a.REGB_Hide and (a.REGS_ID or "") ~= "" then
      item(a.REGS_Category or "", a.REGS_Name or a.REGS_ID, a.REGS_ID, a.REGS_OpIconString or "")
    end
  end
  out("ok", "")
  return
end
-- 0.9.17 (cleanup): "Read DaVinci" in one fuscript call instead of four (status, effects, audio effects, Fusion tools):
-- the same rows, each with its list in front ("v" video, "a" audio, "t" tool; "notools" when Fusion did not answer).
-- The result line is the same as "status". Read only.
if command == "readall" then
  for _, e in ipairs(list(resolve:GetEffectsList("video"))) do item("v", e.category or "", e.name or "", e.id or "") end
  for _, e in ipairs(list(resolve:GetEffectsList("audio"))) do item("a", e.category or "", e.name or "", e.id or "") end
  local fu = resolve:Fusion()
  if fu then
    for _, reg in pairs(fu:GetRegList(fu.CT_Tool) or {}) do
      local a = reg:GetAttrs() or {}
      if not a.REGB_Hide and (a.REGS_ID or "") ~= "" then
        item("t", a.REGS_Category or "", a.REGS_Name or a.REGS_ID, a.REGS_ID, a.REGS_OpIconString or "")
      end
    end
  else item("notools") end
  out("ok", (resolve:GetProductName() or "") .. "|" .. (resolve:GetVersionString() or "") .. "|" .. (resolve:GetCurrentPage() or ""))
  return
end
local project = resolve:GetProjectManager():GetCurrentProject()
if not project then out("err", "Open a project in DaVinci first.") return end
if command == "presets" then
  for _, name in ipairs(list(project:GetRenderPresetList())) do if type(name) == "string" then item(name) end end
  out("ok", "")
  return
end
if command == "render" then
  if not project:LoadRenderPreset(arg[2] or "") then out("err", "Render preset not found: " .. tostring(arg[2])) return end
  local job = project:AddRenderJob()
  if not job or job == "" then out("err", "DaVinci did not add the render job. Check the render settings.") return end
  if arg[3] == "1" then
    if project:StartRendering({job}) then out("ok", "Rendering started") else out("err", "Could not start rendering.") end
  else out("ok", "Added to the render queue") end
  return
end

-- 0.9.6 (Pro): the iPad's Deliver page. "deliverinfo" lists the render presets, the Quick Export presets and the
-- file formats; "delivercodecs <format> [codec]" the codecs of a format and the resolutions of a codec;
-- "deliver key=value…" sets only what was chosen on the iPad, adds the render job and (start=1) starts rendering.
local function strings(t) local o = {} for _, v in pairs(t or {}) do if type(v) == "string" then o[#o + 1] = v end end return o end
if command == "deliverinfo" then
  for _, name in ipairs(strings(project:GetRenderPresetList())) do item("preset", name) end
  local ok, quick = pcall(function() return project:GetQuickExportRenderPresets() end)
  if ok then for _, name in ipairs(strings(quick)) do item("quick", name) end end
  for name, ext in pairs(project:GetRenderFormats() or {}) do if type(ext) == "string" then item("format", name, ext) end end
  local current = project:GetCurrentRenderFormatAndCodec() or {}
  item("current", current.format or "", current.codec or "", tostring(project:GetCurrentRenderMode() or ""))
  out("ok", tostring(project:GetSetting("timelineFrameRate") or ""))
  return
end
if command == "delivercodecs" then
  for name, id in pairs(project:GetRenderCodecs(arg[2] or "") or {}) do if type(id) == "string" then item("codec", name, id) end end
  if (arg[3] or "") ~= "" then
    for _, r in pairs(project:GetRenderResolutions(arg[2], arg[3]) or {}) do if type(r) == "table" then item("res", tostring(r.Width), tostring(r.Height)) end end
  end
  out("ok", "")
  return
end
if command == "deliver" then
  local o = {}
  for n = 2, #arg do local key, value = string.match(arg[n], "^(%w+)=(.*)$") if key then o[key] = value end end
  if (o.quick or "") ~= "" then
    local params = {}
    if (o.dir or "") ~= "" then params.TargetDir = o.dir end
    if (o.name or "") ~= "" then params.CustomName = o.name end
    local ok, result = pcall(function() return project:RenderWithQuickExport(o.quick, params) end)
    if ok and result then out("ok", "quick") else out("err", "DaVinci did not start the Quick Export.") end
    return
  end
  if (o.preset or "") ~= "" and not project:LoadRenderPreset(o.preset) then out("err", "Render preset not found: " .. o.preset) return end
  if o.mode == "single" then project:SetCurrentRenderMode(1) elseif o.mode == "individual" then project:SetCurrentRenderMode(0) end
  if (o.format or "") ~= "" and (o.codec or "") ~= "" and not project:SetCurrentRenderFormatAndCodec(o.format, o.codec) then
    out("err", "DaVinci did not accept this format and codec.") return
  end
  local settings, any = {}, false
  local function set(key, value) settings[key] = value; any = true end
  if (o.dir or "") ~= "" then set("TargetDir", o.dir) end
  if (o.name or "") ~= "" then set("CustomName", o.name) end
  if o.video then set("ExportVideo", o.video == "1") end
  if o.audio then set("ExportAudio", o.audio == "1") end
  if tonumber(o.width or "") and tonumber(o.height or "") then set("FormatWidth", tonumber(o.width)); set("FormatHeight", tonumber(o.height)) end
  if tonumber(o.fps or "") then set("FrameRate", tonumber(o.fps)) end
  if (o.quality or "") ~= "" then set("VideoQuality", tonumber(o.quality) or o.quality) end
  if any and not project:SetRenderSettings(settings) then out("err", "DaVinci did not accept these render settings.") return end
  local job = project:AddRenderJob()
  if not job or job == "" then out("err", "DaVinci did not add the render job. Check the render settings.") return end
  if o.start == "1" then
    if project:StartRendering({job}) then out("ok", "started") else out("err", "Could not start rendering.") end
  else out("ok", "queued") end
  return
end

local timeline = project:GetCurrentTimeline()
if not timeline then out("err", "Open a timeline in DaVinci first.") return end

-- 0.9.14: a Fairlight effect button (the Mac app inserts it with DaVinci's effects search, on the selected track).
-- "fairlightfx <name>": makes sure DaVinci is on Fairlight and counts the audio CLIP effects with that name, so the
-- app can tell afterwards if DaVinci put it on a clip instead of the track. Changes nothing else.
if command == "fairlightfx" then
  if resolve:GetCurrentPage() ~= "fairlight" then resolve:OpenPage("fairlight") end
  local name, count = arg[2] or "", 0
  for t = 1, (timeline:GetTrackCount("audio") or 0) do
    for _, it in ipairs(list(timeline:GetItemListInTrack("audio", t))) do
      for _, e in ipairs(list(it:GetEffects("audio"))) do
        local info = e:GetInfo() or {}
        if info.name == name or string.sub(info.id or "", -(#name + 1)) == "/" .. name then count = count + 1 end
      end
    end
  end
  out("ok", count)
  return
end

-- Timecode <-> frame with the timeline's nominal frame rate.
local fps = math.floor((tonumber(project:GetSetting("timelineFrameRate")) or 24) + 0.5)
local function toFrame(tc)
  local h, m, s, f = string.match(tc or "", "(%d+)[:;](%d+)[:;](%d+)[:;](%d+)")
  if not h then return nil end
  return ((tonumber(h) * 60 + tonumber(m)) * 60 + tonumber(s)) * fps + tonumber(f)
end
local function toTC(frame)
  local sec = math.floor(frame / fps)
  return string.format("%02d:%02d:%02d:%02d", math.floor(sec / 3600), math.floor(sec / 60) % 60, sec % 60, frame % fps)
end
local function trackItems(t) return list(timeline:GetItemListInTrack("video", t)) end
-- 0.9.8: which project and timeline (the app forgets its placed titles when this changes).
local function context() return tostring(project:GetUniqueId() or "") .. "|" .. tostring(timeline:GetUniqueId() or "") end
local function hexText(text) return (string.gsub(text or "", ".", function(c) return string.format("%02x", string.byte(c)) end)) end
local function busy(t, from, to)
  for _, it in ipairs(trackItems(t)) do if it:GetStart() < to and it:GetEnd() > from then return true end end
  return false
end
local function selection()
  local chosen = list(timeline:GetSelectedClips())
  if #chosen == 0 then local current = timeline:GetCurrentVideoItem(); if current then chosen = {current} end end
  if #chosen == 0 then
    -- GetCurrentVideoItem can be empty on the Edit page: the top video clip under the playhead.
    local playhead = toFrame(timeline:GetCurrentTimecode()) or -1
    for t = timeline:GetTrackCount("video"), 1, -1 do
      for _, it in ipairs(trackItems(t)) do if it:GetStart() <= playhead and it:GetEnd() > playhead then return {it} end end
    end
  end
  return chosen
end

-- Titles and generators: inserted at the end of the timeline (nothing to push), then moved to the playhead on the
-- first free video track above the clips there (a new track if needed). Existing clips are never cut or moved.
local function place(insert)
  local playheadTC = timeline:GetCurrentTimecode()
  local playhead = toFrame(playheadTC)
  if not playhead then return nil, "Could not read the playhead." end
  local before = 0
  for t = 1, timeline:GetTrackCount("video") do before = before + #trackItems(t) end
  -- The real end: after the last clip on any track (GetEndFrame can be one frame short, which would cut a clip).
  local last = timeline:GetStartFrame()
  for _, kind in ipairs({"video", "audio", "subtitle"}) do
    for t = 1, (timeline:GetTrackCount(kind) or 0) do
      for _, it in ipairs(list(timeline:GetItemListInTrack(kind, t))) do if it:GetEnd() > last then last = it:GetEnd() end end
    end
  end
  timeline:SetCurrentTimecode(toTC(last + 1))
  local inserted = insert()
  if not inserted then timeline:SetCurrentTimecode(playheadTC); return nil, nil end
  local length = inserted:GetEnd() - inserted:GetStart()
  local endStart, insertedName, insertedID = inserted:GetStart(), inserted:GetName() or "", tostring(inserted:GetUniqueId() or "")
  local count = timeline:GetTrackCount("video")
  local highest = 0
  for t = 1, count do
    for _, it in ipairs(trackItems(t)) do
      if it:GetStart() < playhead + length and it:GetEnd() > playhead and it:GetUniqueId() ~= inserted:GetUniqueId() then highest = t end
    end
  end
  local target = nil
  for t = highest + 1, count do
    local free = true
    for _, it in ipairs(trackItems(t)) do
      if it:GetUniqueId() ~= inserted:GetUniqueId() and it:GetStart() < playhead + length and it:GetEnd() > playhead then free = false end
    end
    if free then target = t break end
  end
  local addedTrack = false
  if not target then timeline:AddTrack("video"); target = timeline:GetTrackCount("video"); addedTrack = true end
  local moved = timeline:MoveItems({inserted}, {trackIndex = target, startFrame = playhead})
  -- The playhead ends at the end of the new title, as when it is added by hand.
  timeline:SetCurrentTimecode(moved and toTC(playhead + length) or playheadTC)
  if not moved then return nil, "DaVinci inserted it but could not move it to a free track; it is at the end of the timeline." end
  local after = 0
  for t = 1, timeline:GetTrackCount("video") do after = after + #trackItems(t) end
  if after ~= before + 1 then return nil, "The timeline changed unexpectedly. Check it, and use Undo if needed." end
  -- 0.9.8: what the app needs to recognise this title after an Undo (see UndoGuard.swift): it is two Undo steps
  -- (insert at the end, then MoveItems), so the first Undo puts it back at endStart. Three when a track was added
  -- (insert, AddTrack, MoveItems; tested).
  print("TTMPLACED\t" .. table.concat({context(), insertedID, hexText(insertedName), tostring(endStart), tostring(length), tostring(target), tostring(playhead), addedTrack and "1" or "0"}, "\t"))
  return target
end
local function insertTitle(name)
  return place(function() return timeline:InsertFusionTitleIntoTimeline(name) or timeline:InsertTitleIntoTimeline(name) end)
end
local function insertGenerator(name)
  return place(function()
    return timeline:InsertFusionGeneratorIntoTimeline(name) or timeline:InsertGeneratorIntoTimeline(name) or timeline:InsertOFXGeneratorIntoTimeline(name)
  end)
end
local function findEffect(name, id, onlyKind)
  for _, kind in ipairs(onlyKind and {onlyKind} or {"video", "audio"}) do
    for _, e in ipairs(list(resolve:GetEffectsList(kind))) do
      if (id and id ~= "" and e.id == id) or (not (id and id ~= "") and string.lower(e.name or "") == string.lower(name or "")) then return e end
    end
  end
  return nil
end
-- Audio effects (Fairlight FX, AU plugins) go on the selected audio clips, or the audio clips under the playhead.
local function audioSelection()
  local chosen = {}
  for _, it in ipairs(list(timeline:GetSelectedClips())) do
    local position = it.GetPosition and it:GetPosition() or nil
    if position and position.trackType == "audio" then chosen[#chosen + 1] = it end
  end
  if #chosen > 0 then return chosen end
  local playhead = toFrame(timeline:GetCurrentTimecode()) or 0
  for t = 1, (timeline:GetTrackCount("audio") or 0) do
    for _, it in ipairs(list(timeline:GetItemListInTrack("audio", t))) do
      if it:GetStart() <= playhead and it:GetEnd() > playhead then chosen[#chosen + 1] = it break end
    end
    if #chosen > 0 then break end
  end
  return chosen
end
local function applyEffect(e)
  local clips = e.category == "audio" and audioSelection() or selection()
  if #clips == 0 and e.category == "audio" then return false, "Select an audio clip in the timeline first." end
  if #clips == 0 then return false, "Select a clip in the timeline first." end
  local done = 0
  -- 0.9.13: TimelineItem:AddEffect switches DaVinci to the Edit page (tested in 21.2). From Fairlight, go back there.
  local startPage = resolve:GetCurrentPage()
  for _, clip in ipairs(clips) do
    if clip:AddEffect(e.category, e.id) then
      for _, applied in ipairs(list(clip:GetEffects(e.category))) do
        local info = applied:GetInfo() or {}
        if info.id == e.id then done = done + 1 break end
      end
    end
  end
  if startPage == "fairlight" and resolve:GetCurrentPage() ~= "fairlight" then resolve:OpenPage("fairlight") end
  if done == 0 then return false, nil end
  return true, done
end

-- 0.9.7: a transition through the API (TimelineItem:AddTransition, DaVinci 21.2; tested): on the selected clip
-- (or the clip under the playhead), at its edge nearest the playhead, centered on the edit, default length.
-- category: "simple" (DaVinci's own: Dissolve, Iris, Motion, Shape, Wipe), "fusion" (Fusion transitions), "ofx".
local function addTransition(name, engine)
  local clips = {}
  for _, it in ipairs(selection()) do if it:GetType() ~= "transition" then clips[#clips + 1] = it end end
  if #clips == 0 then return false, "Select a clip in the timeline first." end
  local playhead = toFrame(timeline:GetCurrentTimecode()) or 0
  local first = (engine == "fusion" or engine == "ofx") and engine or "simple"
  local categories = {first}
  for _, c in ipairs({"simple", "fusion", "ofx"}) do if c ~= first then categories[#categories + 1] = c end end
  local done = 0
  for _, clip in ipairs(clips) do
    local edge = (playhead - clip:GetStart() < clip:GetEnd() - playhead) and "start" or "end"
    for _, category in ipairs(categories) do
      local ok, made = pcall(function() return clip:AddTransition({type = name, category = category, position = edge, alignment = "center"}) end)
      if ok and made then done = done + 1 break end
    end
  end
  if done == 0 then return false, nil end
  return true, done
end
-- 0.9.7: a Fusion page tool by its name (Fusion's own list: "Rectangle" is RectangleMask…) or a macro file.
-- 0.9.11: `toolID` (a button made from the Fusion tool list) = Fusion's registry ID (TextPlus, RectangleMask…), used
-- as it is: a tool with the same name as another (Transform, Glow…) is always the one chosen.
local function addFusionTool(name, macro, toolID)
  local fu = resolve:Fusion()
  local comp = fu and fu:GetCurrentComp()
  if not comp or resolve:GetCurrentPage() ~= "fusion" then return false, "Open the Fusion page with a clip first." end
  if (macro or "") ~= "" then
    local text = bmd.readfile(macro)
    if not text then return false, "Could not read the macro file." end
    comp:Lock(); local ok = comp:Paste(text); comp:Unlock()
    return ok and true or false, nil
  end
  if (toolID or "") ~= "" then
    comp:Lock(); local made = comp:AddTool(toolID, -32768, -32768); comp:Unlock()
    return made and true or false, nil
  end
  local wanted = string.lower(name or "")
  local squeezed = string.gsub(wanted, "%s", "")
  local aliases = { ["text+"] = "TextPlus", ["text 3d"] = "Text3D", ["blur"] = "Blur", ["color corrector"] = "ColorCorrector" }
  local id = aliases[wanted]
  if not id then
    for _, reg in pairs(fu:GetRegList(comp.CT_Tool) or {}) do
      local a = reg:GetAttrs() or {}
      local regName, regID = string.lower(a.REGS_Name or ""), string.lower(a.REGS_ID or "")
      if regName == wanted or regID == wanted then id = a.REGS_ID break end
      if not id and (string.gsub(regName, "%s", "") == squeezed or regID == squeezed) then id = a.REGS_ID end
    end
  end
  id = id or string.gsub(name or "", "%s", "")
  comp:Lock(); local tool = comp:AddTool(id, -32768, -32768); comp:Unlock()
  return tool and true or false, nil
end

if command == "title" or command == "generator" then
  local track, problem = (command == "title" and insertTitle or insertGenerator)(arg[2])
  if track then out("ok", "V" .. track) elseif problem then out("err", problem) else out("none", "") end
  return
end
-- 0.9.2: a button from the DaVinci list knows what it is: insert <type> <engine> <exact name> [effect id].
-- Titles: "fusion" = InsertFusionTitleIntoTimeline (Fusion titles, the user's .setting/.drfx titles), "standard" =
-- InsertTitleIntoTimeline (Text, Scroll, lower thirds). Generators: fusion, standard or ofx. The other call is tried too.
-- Effects and audio effects: AddEffect with the id. 0.9.7: transitions with TimelineItem:AddTransition (21.2).
if command == "insert" then
  local kind, engine, name, id = arg[2] or "", arg[3] or "", arg[4] or "", arg[5] or ""
  if kind == "title" then
    local track, problem = place(function()
      if engine == "standard" then return timeline:InsertTitleIntoTimeline(name) or timeline:InsertFusionTitleIntoTimeline(name) end
      return timeline:InsertFusionTitleIntoTimeline(name) or timeline:InsertTitleIntoTimeline(name)
    end)
    if track then out("ok", "V" .. track) elseif problem then out("err", problem) else out("none", "") end
    return
  end
  if kind == "generator" then
    local track, problem = place(function()
      local calls = {
        fusion = function() return timeline:InsertFusionGeneratorIntoTimeline(name) end,
        standard = function() return timeline:InsertGeneratorIntoTimeline(name) end,
        ofx = function() return timeline:InsertOFXGeneratorIntoTimeline(name) end }
      local first = calls[engine]
      local made = first and first() or nil
      for _, key in ipairs({"fusion", "standard", "ofx"}) do if made then break end if key ~= engine then made = calls[key]() end end
      return made
    end)
    if track then out("ok", "V" .. track) elseif problem then out("err", problem) else out("none", "") end
    return
  end
  if kind == "effect" or kind == "audio" then
    local e = findEffect(name, id, kind == "audio" and "audio" or "video") or findEffect(name, nil, kind == "audio" and "audio" or "video")
    if not e then out("none", "") return end
    local ok, detail = applyEffect(e)
    if ok then out("ok", detail) elseif detail then out("err", detail) else out("none", "") end
    return
  end
  if kind == "transition" then
    local ok, detail = addTransition(name, engine)
    if ok then out("ok", detail) elseif detail then out("err", detail) else out("none", "") end
    return
  end
  out("none", "")
  return
end
if command == "effect" then
  local e = findEffect(arg[2], arg[3])
  if not e then out("none", "") return end
  local ok, detail = applyEffect(e)
  if ok then out("ok", detail) elseif detail then out("err", detail) else out("none", "") end
  return
end
if command == "smart" then
  -- A plain search button: try a title, then an effect on the selected clip, then a generator, then (0.9.7) a
  -- transition. "smart <name> 1 [macro file] [tool id]" = a Fusion page tool or macro.
  local name, fusionTool = arg[2], arg[3] == "1"
  if fusionTool then
    local ok, detail = addFusionTool(name, arg[4], arg[5])
    if ok then out("ok", "tool") elseif detail then out("err", detail) else out("none", "") end
    return
  end
  local track, problem = insertTitle(name)
  if track then out("ok", "title V" .. track) return end
  if problem then out("err", problem) return end
  local e = findEffect(name, nil)
  if e then
    local ok, detail = applyEffect(e)
    if ok then out("ok", "effect") elseif detail then out("err", detail) else out("none", "") end
    return
  end
  track, problem = insertGenerator(name)
  if track then out("ok", "generator V" .. track) return end
  if problem then out("err", problem) return end
  local ok, detail = addTransition(name, "")
  if ok then out("ok", "transition") elseif detail then out("err", detail) else out("none", "") end
  return
end
-- Color page nodes: prints "<count>|<clip id>|<corrector numbers>" for the clip under the playhead (the clip shown
-- in Color). count = all nodes, mixers included (GetNumNodes). DaVinci numbers every node in tree order and a
-- Parallel/Layer Mixer, splitter or combiner takes a number too (it is not shown on the mixer), so the correctors
-- can be 1,2,3,5…; only correctors have a LUT slot (GetLUT gives nothing for the others). Tested in 21.1.2.
-- The API cannot select a node (Graph:SetNodeActive does not change the current node in 21.1.2; tested),
-- so the Mac app selects nodes with DaVinci's keys.
if command == "nodes" then
  local clip = timeline:GetCurrentVideoItem()
  if not clip then out("err", "No clip under the playhead.") return end
  local graph = clip:GetNodeGraph()
  local total = (graph and graph:GetNumNodes()) or clip:GetNumNodes() or 0
  local numbers = {}
  for i = 1, total do
    local ok, lut = pcall(function() return graph:GetLUT(i) end)
    if not graph or (ok and lut ~= nil) then numbers[#numbers + 1] = tostring(i) end
  end
  out("ok", tostring(total) .. "|" .. tostring(clip:GetUniqueId() or "") .. "|" .. table.concat(numbers, ","))
  return
end
-- Node order for finding the current node (SearchExecutor.goToNode): "<count>|<token>,<token>…", one token per
-- node in number order: "m" = mixer/splitter/combiner, "c<hex label>" = corrector. "nodemark" sends the same and
-- then labels every corrector "ttm<number>" (so a helper node added by keys is the one without a label);
-- "noderestore <number>:<hex label>…" gives each "ttm<number>" node its label back. DaVinci's Undo restores the
-- grade as it was before the last key action, so these label changes never become a step of their own.
local function hex(text) return (string.gsub(text or "", ".", function(c) return string.format("%02x", string.byte(c)) end)) end
local function unhex(text) return (string.gsub(text or "", "%x%x", function(h) return string.char(tonumber(h, 16)) end)) end
if command == "nodeorder" or command == "nodemark" or command == "noderestore" then
  local clip = timeline:GetCurrentVideoItem()
  local graph = clip and clip:GetNodeGraph()
  if not graph then out("err", "No clip under the playhead.") return end
  local total = graph:GetNumNodes() or 0
  local tokens, correctors = {}, {}
  for i = 1, total do
    local ok, lut = pcall(function() return graph:GetLUT(i) end)
    if ok and lut ~= nil then
      correctors[#correctors + 1] = i
      tokens[#tokens + 1] = "c" .. hex(graph:GetNodeLabel(i) or "")
    else tokens[#tokens + 1] = "m" end
  end
  if command == "noderestore" then
    local saved = {}
    for n = 2, #arg do local number, label = string.match(arg[n], "^(%d+):(%x*)$") if number then saved["ttm" .. number] = unhex(label) end end
    local left = 0
    for _, i in ipairs(correctors) do
      local label = graph:GetNodeLabel(i) or ""
      if saved[label] ~= nil then if not graph:SetNodeLabel(i, saved[label]) then left = left + 1 end
      elseif string.match(label, "^ttm%d+$") then left = left + 1 end
    end
    if left == 0 then out("ok", "") else out("err", "Could not give " .. left .. " node(s) their label back.") end
    return
  end
  if command == "nodemark" then
    for _, i in ipairs(correctors) do graph:SetNodeLabel(i, "ttm" .. i) end
  end
  out("ok", tostring(total) .. "|" .. table.concat(tokens, ","))
  return
end
-- 0.9.8: where the titles and generators the app placed are now. Each argument: "id|endStart|length|track|frame|hex name".
-- Prints the context and, per argument, "TTMITEM <n> end|placed|other|gone <id>": end = back at the end of the
-- timeline where it was inserted (its MoveItems was undone), placed = where the app moved it, other = somewhere
-- else, gone = not in the timeline. Matched by unique id (by name at that exact place and length only without one).
-- Then "TTMITEM tracks <video track count>".
if command == "undostate" then
  local all = {}
  for t = 1, timeline:GetTrackCount("video") do
    for _, it in ipairs(trackItems(t)) do all[#all + 1] = {item = it, track = t, id = tostring(it:GetUniqueId() or ""), start = it:GetStart(), length = it:GetEnd() - it:GetStart()} end
  end
  for n = 2, #arg do
    local id, endStart, length, track, frame, name = string.match(arg[n], "^([^|]*)|(%-?%d+)|(%d+)|(%d+)|(%-?%d+)|(%x*)$")
    local state, found = "gone", id or ""
    if id then
      endStart, length, track, frame = tonumber(endStart), tonumber(length), tonumber(track), tonumber(frame)
      -- The unique id stays the same through Undo and Redo (tested), so it is the match; the name only without an id.
      local function same(e) if id ~= "" then return e.id == id end return hexText(e.item:GetName() or "") == name end
      for _, e in ipairs(all) do
        if same(e) and e.length == length and e.start == endStart then state, found = "end", e.id break end
      end
      if state == "gone" then
        for _, e in ipairs(all) do
          if same(e) and e.length == length and e.start == frame and e.track == track then state, found = "placed", e.id break end
        end
      end
      if state == "gone" and id ~= "" then
        for _, e in ipairs(all) do if e.id == id then state = "other" break end end
      end
    end
    item(tostring(n - 1), state, found)
  end
  item("tracks", tostring(timeline:GetTrackCount("video")))
  out("ok", context())
  return
end
-- 0.9.27: "playhead <frame>": puts the playhead on that frame (after an Undo of a title or generator the app placed,
-- it goes back to where it was before the button).
if command == "playhead" then
  local frame = tonumber(arg[2] or "")
  if frame and timeline:SetCurrentTimecode(toTC(frame)) then out("ok", "") else out("none", "") end
  return
end
if command == "marker" then
  local playhead = toFrame(timeline:GetCurrentTimecode())
  local frame = playhead and (playhead - timeline:GetStartFrame()) or nil
  if not frame then out("err", "Could not read the playhead.") return end
  -- 0.9.6: DaVinci 21.2 does not add a marker with an empty name (tested), so a marker without a name is called "Marker".
  local name = arg[3] or ""
  if name == "" then name = "Marker" end
  if (timeline:GetMarkers() or {})[frame] then out("err", "There is already a marker on this frame.") return end
  if timeline:AddMarker(frame, arg[2] or "Blue", name, "", 1, "") then out("ok", "") else out("err", "DaVinci did not add the marker.") end
  return
end
if command == "still" then
  if timeline:GrabStill() then out("ok", "") else out("err", "DaVinci did not grab the still. Open the Color page with a clip under the playhead.") end
  return
end
if command == "lut" then
  local clips = selection()
  if #clips == 0 then out("err", "Select a clip in the timeline first.") return end
  local done = 0
  for _, clip in ipairs(clips) do
    local graph = clip:GetNodeGraph()
    if graph and graph:SetLUT(math.max(graph:GetNumNodes() or 1, 1), arg[2]) then done = done + 1 end
  end
  if done > 0 then out("ok", done) else out("err", "DaVinci did not apply the LUT.") end
  return
end
out("err", "Unknown command")
